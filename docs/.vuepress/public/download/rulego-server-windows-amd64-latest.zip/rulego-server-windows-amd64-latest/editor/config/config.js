window.rulegoEditorConfig = {
    baseUrl: 'http://127.0.0.1:9090',//rulego-server api地址
    wsUrl: 'ws://127.0.0.1:9090',
};